package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.book.dto.BookBean;
import com.capgemini.book.exception.BookException;
import com.capgemini.service.BookService;

@RestController
public class BookController {
	@Autowired
	BookService bookService;
		@PostMapping("/books")
		public BookBean createBook(@RequestBody BookBean book) {
			 return bookService.createBook(book);
		}
		@GetMapping("/books")
		public List<BookBean> showAllBooks() throws BookException{
			return bookService.showAllBooks();
		}
		
		@PutMapping("/books/{id}")
		public List<BookBean> editBook(@PathVariable int id, @RequestBody BookBean book) throws BookException {
			 return bookService.editBook(id,book);
		}
		@DeleteMapping("/books/{id}")
		public List<BookBean> deleteBook(@PathVariable int id) throws BookException {
			return bookService.deleteBook(id);
		}
			
}
