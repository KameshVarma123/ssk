package com.capgemini.book.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.book.dto.BookBean;
@Repository
public interface BookDao extends JpaRepository<BookBean, Integer>{

}
