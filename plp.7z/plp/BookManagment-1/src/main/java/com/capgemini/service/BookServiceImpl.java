package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.book.dao.BookDao;
import com.capgemini.book.dto.BookBean;
import com.capgemini.book.exception.BookException;




@Service
public class BookServiceImpl implements BookService {
	@Autowired
	 BookDao bankDao;
	@Override
	public BookBean createBook(BookBean book) {
		BookBean bean=new BookBean();
		bankDao.save(book);
		return bankDao.save(book);
	}

	@Override
	public List<BookBean> showAllBooks() {
	
		return bankDao.findAll();
	}

	@Override
	public List<BookBean> deleteBook(int id) throws BookException {
		if(bankDao.existsById(id)) {
			bankDao.deleteById(id);
			return showAllBooks();
		}
		else {
			throw new BookException("Cannot Delete.Employee with Id " + id+" does not exist" );
		}
	}

	@Override
	public List<BookBean> editBook(int id,BookBean book) throws BookException {
		
		if(bankDao.existsById(book.getId())) {
			bankDao.save(book);
			return showAllBooks();
		}
		else {
			throw new BookException("Invalid Employee, cannot be updated");
		}
	}

}
