package com.capgemini.service;

import java.util.List;

import com.capgemini.book.dto.BookBean;
import com.capgemini.book.exception.BookException;

public interface BookService {
public BookBean createBook(BookBean book);
public List<BookBean> showAllBooks() throws BookException;
public List<BookBean> deleteBook(int id) throws BookException;
public List<BookBean> editBook(int id,BookBean book) throws BookException;
}
