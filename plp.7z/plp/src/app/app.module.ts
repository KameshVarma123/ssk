import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookllistingpageComponent } from './book/bookllistingpage.component';
import { CreatenewbookpageComponent } from './book/createnewbookpage.component';
import { EditbookpageComponent } from './book/editbookpage.component';
import { DeletebookageComponent } from './book/deletebookage.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BookServiceService } from './book/book-service.service';
@NgModule({
  declarations: [
    AppComponent,
    BookllistingpageComponent,
    CreatenewbookpageComponent,
    EditbookpageComponent,
    DeletebookageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, HttpClientModule
  ],
  providers: [BookServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
