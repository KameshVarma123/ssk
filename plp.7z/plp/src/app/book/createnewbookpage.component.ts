import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createnewbookpage',
  templateUrl: './createnewbookpage.component.html',
  styleUrls: ['./createnewbookpage.component.css']
})
export class CreatenewbookpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  $scope: any = [
                {model : "programming", color : "red"},
                {model : "Buisiness", color : "white"},
                {model : "Health", color : "black"},
                {model : "Marketting", color : "black"},
                {model : "Technology", color : "black"},
                {model : "Lifestyle", color : "black"},
                {model : "History", color : "black"},
              ];
}
