import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookllistingpage',
  templateUrl: './bookllistingpage.component.html',
  styleUrls: ['./bookllistingpage.component.css']
})
export class BookllistingpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
