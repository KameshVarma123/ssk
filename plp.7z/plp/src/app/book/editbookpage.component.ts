import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editbookpage',
  templateUrl: './editbookpage.component.html',
  styleUrls: ['./editbookpage.component.css']
})
export class EditbookpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
