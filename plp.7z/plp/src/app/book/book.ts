export class Book {
    image:Blob;
    title:string;
    author:string;
    category:string;
    isbn:number;
    price:number;
    description:string;
    pdate:number;
}
