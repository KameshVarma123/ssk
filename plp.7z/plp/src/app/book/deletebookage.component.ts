import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletebookage',
  templateUrl: './deletebookage.component.html',
  styleUrls: ['./deletebookage.component.css']
})
export class DeletebookageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
