import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookllistingpageComponent } from './book/bookllistingpage.component';
import { CreatenewbookpageComponent } from './book/createnewbookpage.component';
import { DeletebookageComponent } from './book/deletebookage.component';
import { EditbookpageComponent } from './book/editbookpage.component';


const routes: Routes = [{path:'',component:BookllistingpageComponent},
{path:'create',component:CreatenewbookpageComponent},
{path:'delete',component:DeletebookageComponent},
{path:'edit',component:EditbookpageComponent}];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
